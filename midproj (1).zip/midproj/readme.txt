CSS-Bootstrap:
table的样式是：
table table-bordered table-striped，也就是带边框的table并用线条隔开，用于pdf输出
table table-bordered，白天使用
table table-bordered table-dark，夜间使用
配合Flask-moment来本地化时间

form风格可以用于登陆

button暂时还没想到用在哪里

使用Alerts来提示信息

表单：WTF处理